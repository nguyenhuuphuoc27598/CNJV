package edu.fa;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.fa.dao.StudentHibernateDao;
import edu.fa.dao.StudentJdbcTemplateDao;
import edu.fa.model.Student;
import edu.fa.service.StudentService;

public class StudentManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
//		StudentHibernateDao dao= context.getBean("studentHibernateDao",StudentHibernateDao.class);
//		dao.save(new Student(1,"phuoc", "quynhon"));
//		dao.save(new Student(1,"ngao", "quynhon"));
//		System.out.println(dao.getAllStrudent());
		StudentService service= context.getBean("studentService",StudentService.class);
		//service.save(new Student("lplp","quynhon"));
		service.test();
	}

}
