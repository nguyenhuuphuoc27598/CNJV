package edu.fa.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import edu.fa.model.Student;

@Component
public class StudentJdbcDao {

	 private  String dbURL = "jdbc:derby://localhost:1527/education;create=true";
	    private  String tableName = "restaurants";
	    // jdbc Connection
	    private  Connection conn = null;
	    private  Statement stmt = null;
	    public void insertStudent(Student st)
	    {
	    	createConnection();
	        try
	        {
	            stmt = conn.createStatement();
	            stmt.execute("insert into Student  values (" +
	                    st.getId() + ",'" + st.getName() + "','" + st.getLocation() +"')");
	            stmt.close();
	        }
	        catch (SQLException sqlExcept)
	        {
	            sqlExcept.printStackTrace();
	        }
	    }
	    public List<Student> getAllStrudent()
	    {
	    	createConnection();
	    	List<Student> students= new ArrayList<Student>();
	        try
	        {
	        	stmt = conn.createStatement();
	            ResultSet results = stmt.executeQuery("select * from Student");
	            ResultSetMetaData rsmd = results.getMetaData();
	            while(results.next())
	            {
	                int id = results.getInt(1);
	                String name = results.getString(2);
	                String location = results.getString(3);
	               students.add(new Student(id,name,location));
	            }
	            results.close();
	            stmt.close();
	        }
	        catch (SQLException sqlExcept)
	        {
	            sqlExcept.printStackTrace();
	        }
	        return students ;
	    }
	    private  void createConnection()
	    {
	    	if(conn==null) {
	        try
	        {
	            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
	            //Get a connection
	            conn = DriverManager.getConnection(dbURL); 
	        }
	        catch (Exception except)
	        {
	            except.printStackTrace();
	        }
	    	}
	    }
	    private  void shutdown()
	    {
	        try
	        {
	            if (stmt != null)
	            {
	                stmt.close();
	            }
	            if (conn != null)
	            {
	                DriverManager.getConnection(dbURL + ";shutdown=true");
	                conn.close();
	            }           
	        }
	        catch (SQLException sqlExcept)
	        {
	            
	        }

	    }
	    
}
	