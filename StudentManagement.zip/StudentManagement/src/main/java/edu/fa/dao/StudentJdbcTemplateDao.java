package edu.fa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.fa.model.Student;

@Component
public class StudentJdbcTemplateDao {

    private  String tableName = "restaurants";
    // jdbc Connection
    private  Connection conn = null;
    private  Statement stmt = null;
    @Autowired
    private DataSource dataSource ;
    private JdbcTemplate jdbcTemplate=new JdbcTemplate();
    public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void insertStudent(Student st)
    {
		jdbcTemplate.setDataSource(getDataSource());
		String sql ="insert into Student  values (" +
                st.getId() + ",'" + st.getName() + "','" + st.getLocation() +"')";
		jdbcTemplate.execute(sql);
    }
    public List<Student> getAllStrudent()
    {
    	createConnection();
    	List<Student> students= new ArrayList<Student>();
        try
        {
        	stmt = conn.createStatement();
            ResultSet results = stmt.executeQuery("select * from Student");
            ResultSetMetaData rsmd = results.getMetaData();
            while(results.next())
            {
                int id = results.getInt(1);
                String name = results.getString(2);
                String location = results.getString(3);
               students.add(new Student(id,name,location));
            }
            results.close();
            stmt.close();
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
        return students ;
    }
    private  void createConnection()
    {
    	if(conn==null) {
        try
        {
            conn = dataSource.getConnection();
        }
        catch (Exception except)
        {
            except.printStackTrace();
        }
    	}
    }
    private  void shutdown()
    {
        try
        {
            if (stmt != null)
            {
                stmt.close();
            }
            if (conn != null)
            {
                conn.close();
            }           
        }
        catch (SQLException sqlExcept)
        {
            
        }

    }
}
